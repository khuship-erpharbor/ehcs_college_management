# -*- coding: utf-8 -*-
from . import wiz_update_tms_entries
